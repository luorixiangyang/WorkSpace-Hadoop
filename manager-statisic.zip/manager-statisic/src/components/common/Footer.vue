<template>
    <div>
        页面尾部
    </div>
</template>

<script>
export default {
  name: 'Footer'
}
</script>