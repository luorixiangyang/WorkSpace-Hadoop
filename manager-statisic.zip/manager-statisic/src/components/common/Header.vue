<template>
    <div>
        页面头部
    </div>
</template>

<script>
export default {
  name: 'Header'
}
</script>